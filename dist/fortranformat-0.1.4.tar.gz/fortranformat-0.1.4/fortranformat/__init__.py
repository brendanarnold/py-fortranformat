__version__ = '0.1.4'

from FortranRecordReader import FortranRecordReader
from FortranRecordWriter import FortranRecordWriter 
